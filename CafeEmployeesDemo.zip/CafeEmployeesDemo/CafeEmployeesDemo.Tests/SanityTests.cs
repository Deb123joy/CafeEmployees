﻿using Xunit;
namespace CafeEmployeesDemo.CafeEmployeesDemo.Tests
{
    public class SanityTests
    {
        [Fact]
        public void TestFrameworkWorks()
        {
            Assert.True(1 + 1 == 2);
        }
    }
}
